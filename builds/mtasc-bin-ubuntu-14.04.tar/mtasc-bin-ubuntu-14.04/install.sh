#!/bin/bash

echo 'Installing MTASC...'

cp -R * /usr/local/bin

echo 'Done!'
